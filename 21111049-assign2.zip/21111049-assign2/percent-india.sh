#!/bin/bash
python3 dmq1.py
