#!/bin/bash
python3 dmq4a.py
