#!/bin/bash
python3 dmq3.py
