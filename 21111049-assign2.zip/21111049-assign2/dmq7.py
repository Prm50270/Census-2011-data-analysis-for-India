#!/usr/bin/env python
# coding: utf-8

# In[1]:


import numpy as np 
import pandas as pd


# Part a
# North Region

# In[2]:


df=pd.read_excel("DDW-C17-0100.XLSX") #Reading data of Jammu and Kashmir
df.head(10)


# In[3]:


df=df[['Unnamed: 1','Unnamed: 3','Unnamed: 4']]
df.columns = ['StateName','LanguageName','TotalSpeaker']
df=df.iloc[5:]
df=df.dropna(axis=0)
df.head(10)


# In[4]:


df1=pd.read_excel("DDW-C17-0200.XLSX")            #Reading data of Himachal Pradesh
df1=df1[['Unnamed: 1','Unnamed: 3','Unnamed: 4']]
df1.columns = ['StateName','LanguageName','TotalSpeaker']
df1=df1.iloc[5:]
df1=df1.dropna(axis=0)
df1.head(10)


# In[5]:


df2=pd.read_excel("DDW-C17-0300.XLSX")             #Reading data of Punjab
df2=df2[['Unnamed: 1','Unnamed: 3','Unnamed: 4']]
df2.columns = ['StateName','LanguageName','TotalSpeaker']
df2=df2.iloc[5:]
df2=df2.dropna(axis=0)
df2.head(10)


# In[6]:


df3=pd.read_excel("DDW-C17-0400.XLSX")            #Reading data of Chandigarh
df3=df3[['Unnamed: 1','Unnamed: 3','Unnamed: 4']]
df3.columns = ['StateName','LanguageName','TotalSpeaker']
df3=df3.iloc[5:]
df3=df3.dropna(axis=0)
df3.head(10)


# In[7]:


df4=pd.read_excel("DDW-C17-0500.XLSX")             #Reading data of Uttarakhand
df4=df4[['Unnamed: 1','Unnamed: 3','Unnamed: 4']]
df4.columns = ['StateName','LanguageName','TotalSpeaker']
df4=df4.iloc[5:]
df4=df4.dropna(axis=0)
df4.head(10)


# In[8]:


df5=pd.read_excel("DDW-C17-0600.XLSX")              #Reading data of Haryana
df5=df5[['Unnamed: 1','Unnamed: 3','Unnamed: 4']]
df5.columns = ['StateName','LanguageName','TotalSpeaker']
df5=df5.iloc[5:]
df5=df5.dropna(axis=0)
df5.head(10)


# In[9]:


df6=pd.read_excel("DDW-C17-0700.XLSX")           #Reading data of Delhi
df6=df6[['Unnamed: 1','Unnamed: 3','Unnamed: 4']]
df6.columns = ['StateName','LanguageName','TotalSpeaker']
df6=df6.iloc[5:]
df6=df6.dropna(axis=0)
df6.head(10)


# In[10]:


dfnorth= pd.concat([df,df1,df2,df3,df4,df5,df6], axis=0) 
dfnorth.shape


# In[11]:


df.head(2)


# In[12]:


dfnorth=dfnorth[['LanguageName','TotalSpeaker']]
dfnorth=dfnorth[dfnorth['LanguageName']!='OTHERS']
dfnorth=(dfnorth.groupby(dfnorth['LanguageName'],as_index=False).aggregate(np.sum).reindex(columns=dfnorth.columns))
dfnorth=dfnorth.sort_values(by=['TotalSpeaker'], ascending=False)


# In[13]:


dfnorth.head(3)
dfnorth=dfnorth[0:3]
dfnorth=dfnorth[['LanguageName']]
north=dfnorth['LanguageName'].tolist()
north.insert(0,'North')
print(north)


# West Region

# In[14]:


df1=pd.read_excel("DDW-C17-0800.XLSX")            #Reading data of Rajasthan
df1=df1[['Unnamed: 1','Unnamed: 3','Unnamed: 4']]
df1.columns = ['StateName','LanguageName','TotalSpeaker']
df1=df1.iloc[5:]
df1=df1.dropna(axis=0)
df1.head(10)


# In[15]:


df2=pd.read_excel("DDW-C17-2400.XLSX")               #Reading data of Gujrat
df2=df2[['Unnamed: 1','Unnamed: 3','Unnamed: 4']]
df2.columns = ['StateName','LanguageName','TotalSpeaker']
df2=df2.iloc[5:]
df2=df2.dropna(axis=0)
df2.head(10)


# In[16]:


df3=pd.read_excel("DDW-C17-2700.XLSX")             #Reading data of Maharashtra
df3=df3[['Unnamed: 1','Unnamed: 3','Unnamed: 4']]
df3.columns = ['StateName','LanguageName','TotalSpeaker']
df3=df3.iloc[5:]
df3=df3.dropna(axis=0)
df3.head(1)


# In[17]:


df4=pd.read_excel("DDW-C17-3000.XLSX") 
df4=df4[['Unnamed: 1','Unnamed: 3','Unnamed: 4']]
df4.columns = ['StateName','LanguageName','TotalSpeaker']
df4=df4.iloc[5:]
df4=df4.dropna(axis=0)
df4.head(1)


# In[18]:


df5=pd.read_excel("DDW-C17-2500.XLSX")                #Reading data of Daman and Diu
df5=df5[['Unnamed: 1','Unnamed: 3','Unnamed: 4']]
df5.columns = ['StateName','LanguageName','TotalSpeaker']
df5=df5.iloc[5:]
df5=df5.dropna(axis=0)
df5.head(1)


# In[19]:


df6=pd.read_excel("DDW-C17-2600.XLSX")              #Reading data of Dadra and Nagar Haveli
df6=df6[['Unnamed: 1','Unnamed: 3','Unnamed: 4']]
df6.columns = ['StateName','LanguageName','TotalSpeaker']
df6=df6.iloc[5:]
df6=df6.dropna(axis=0)
df6.head(1)


# In[20]:


dfwest= pd.concat([df1,df2,df3,df4,df5,df6], axis=0)
dfwest=dfwest[['LanguageName','TotalSpeaker']]
dfwest=dfwest[dfwest['LanguageName']!='OTHERS']
dfwest=(dfwest.groupby(dfwest['LanguageName'],as_index=False).aggregate(np.sum).reindex(columns=dfwest.columns))
dfwest=dfwest.sort_values(by=['TotalSpeaker'], ascending=False)
dfwest=dfwest[0:3]
dfwest=dfwest[['LanguageName']]
west=dfwest['LanguageName'].tolist()
west.insert(0,'West')
print(west)


# Central Region

# In[21]:


df1=pd.read_excel("DDW-C17-2300.XLSX")              #Reading data of Madhya pradesh
df1=df1[['Unnamed: 1','Unnamed: 3','Unnamed: 4']]
df1.columns = ['StateName','LanguageName','TotalSpeaker']
df1=df1.iloc[5:]
df1=df1.dropna(axis=0)

df2=pd.read_excel("DDW-C17-0900.XLSX")             #Reading data of Uttar Pradesh
df2=df2[['Unnamed: 1','Unnamed: 3','Unnamed: 4']]
df2.columns = ['StateName','LanguageName','TotalSpeaker']
df2=df2.iloc[5:]
df2=df2.dropna(axis=0)

df3=pd.read_excel("DDW-C17-2200.XLSX")           #Reading data of Chattisgarh
df3=df3[['Unnamed: 1','Unnamed: 3','Unnamed: 4']]
df3.columns = ['StateName','LanguageName','TotalSpeaker']
df3=df3.iloc[5:]
df3=df3.dropna(axis=0)


# In[22]:


dfcentral= pd.concat([df1,df2,df3], axis=0)
dfcentral=dfcentral[['LanguageName','TotalSpeaker']]
dfcentral=dfcentral[dfcentral['LanguageName']!='OTHERS']
dfcentral=(dfcentral.groupby(dfcentral['LanguageName'],as_index=False).aggregate(np.sum).reindex(columns=dfcentral.columns))
dfcentral=dfcentral.sort_values(by=['TotalSpeaker'], ascending=False)
dfcentral=dfcentral[0:3]
central=dfcentral['LanguageName'].tolist()
central.insert(0,'Central')
print(central)


# East Region

# In[23]:


df1=pd.read_excel("DDW-C17-1000.XLSX")               #Reading data of Bihar
df1=df1[['Unnamed: 1','Unnamed: 3','Unnamed: 4']]
df1.columns = ['StateName','LanguageName','TotalSpeaker']
df1=df1.iloc[5:]
df1=df1.dropna(axis=0)

df2=pd.read_excel("DDW-C17-1900.XLSX")             #Reading data of West Bengal
df2=df2[['Unnamed: 1','Unnamed: 3','Unnamed: 4']]
df2.columns = ['StateName','LanguageName','TotalSpeaker']
df2=df2.iloc[5:]
df2=df2.dropna(axis=0)

df3=pd.read_excel("DDW-C17-2100.XLSX")            #Reading data of Odhisa
df3=df3[['Unnamed: 1','Unnamed: 3','Unnamed: 4']]
df3.columns = ['StateName','LanguageName','TotalSpeaker']
df3=df3.iloc[5:]
df3=df3.dropna(axis=0)

df4=pd.read_excel("DDW-C17-2000.XLSX")           #Reading data of Jharkhand
df4=df4[['Unnamed: 1','Unnamed: 3','Unnamed: 4']]
df4.columns = ['StateName','LanguageName','TotalSpeaker']
df4=df4.iloc[5:]


# In[24]:


dfeast= pd.concat([df1,df2,df3,df4], axis=0)
dfeast=dfeast[['LanguageName','TotalSpeaker']]
dfeast=dfeast[dfeast['LanguageName']!='OTHERS']
dfeast=(dfeast.groupby(dfeast['LanguageName'],as_index=False).aggregate(np.sum).reindex(columns=dfeast.columns))
dfeast=dfeast.sort_values(by=['TotalSpeaker'], ascending=False)
dfeast=dfeast[0:3]
east=dfeast['LanguageName'].tolist()
east.insert(0,'East')
print(east)


# South Region

# In[25]:


df1=pd.read_excel("DDW-C17-2900.XLSX")           #Reading data of Karnataka
df1=df1[['Unnamed: 1','Unnamed: 3','Unnamed: 4']]
df1.columns = ['StateName','LanguageName','TotalSpeaker']
df1=df1.iloc[5:]
df1=df1.dropna(axis=0)

df2=pd.read_excel("DDW-C17-2800.XLSX")         #Reading data of Andhra Pradesh
df2=df2[['Unnamed: 1','Unnamed: 3','Unnamed: 4']]
df2.columns = ['StateName','LanguageName','TotalSpeaker']
df2=df2.iloc[5:]
df2=df2.dropna(axis=0)

df3=pd.read_excel("DDW-C17-3300.XLSX")        #Reading data of TamilNadu
df3=df3[['Unnamed: 1','Unnamed: 3','Unnamed: 4']]
df3.columns = ['StateName','LanguageName','TotalSpeaker']
df3=df3.iloc[5:]
df3=df3.dropna(axis=0)

df4=pd.read_excel("DDW-C17-3200.XLSX")       #Reading data of Kerala
df4=df4[['Unnamed: 1','Unnamed: 3','Unnamed: 4']]
df4.columns = ['StateName','LanguageName','TotalSpeaker']
df4=df4.iloc[5:]
df4=df4.dropna(axis=0)

df5=pd.read_excel("DDW-C17-3100.XLSX")       #Reading data of Lakshdweep
df5=df5[['Unnamed: 1','Unnamed: 3','Unnamed: 4']]
df5.columns = ['StateName','LanguageName','TotalSpeaker']
df5=df5.iloc[5:]
df5=df5.dropna(axis=0)

df6=pd.read_excel("DDW-C17-3400.XLSX")       #Reading data of Puducherry
df6=df6[['Unnamed: 1','Unnamed: 3','Unnamed: 4']]
df6.columns = ['StateName','LanguageName','TotalSpeaker']
df6=df6.iloc[5:]
df6=df6.dropna(axis=0)


# In[26]:


dfsouth= pd.concat([df1,df2,df3,df4,df5,df6], axis=0)
dfsouth=dfsouth[['LanguageName','TotalSpeaker']]
dfsouth=dfsouth[dfsouth['LanguageName']!='OTHERS']
dfsouth=(dfsouth.groupby(dfsouth['LanguageName'],as_index=False).aggregate(np.sum).reindex(columns=dfsouth.columns))
dfsouth=dfsouth.sort_values(by=['TotalSpeaker'], ascending=False)
dfsouth=dfsouth[0:3]
south=dfsouth['LanguageName'].tolist()
south.insert(0,'South')
print(south)

#North-East Region
# In[27]:


df1=pd.read_excel("DDW-C17-1800.XLSX")          #Reading data of Assam
df1=df1[['Unnamed: 1','Unnamed: 3','Unnamed: 4']]
df1.columns = ['StateName','LanguageName','TotalSpeaker']
df1=df1.iloc[5:]
df1=df1.dropna(axis=0)

df2=pd.read_excel("DDW-C17-1100.XLSX")         #Reading data of Sikkim
df2=df2[['Unnamed: 1','Unnamed: 3','Unnamed: 4']]
df2.columns = ['StateName','LanguageName','TotalSpeaker']
df2=df2.iloc[5:]
df2=df2.dropna(axis=0)

df3=pd.read_excel("DDW-C17-1700.XLSX")         #Reading data of Meghalaya
df3=df3[['Unnamed: 1','Unnamed: 3','Unnamed: 4']]
df3.columns = ['StateName','LanguageName','TotalSpeaker']
df3=df3.iloc[5:]
df3=df3.dropna(axis=0)

df4=pd.read_excel("DDW-C17-1600.XLSX")         #Reading data of Tripura
df4=df4[['Unnamed: 1','Unnamed: 3','Unnamed: 4']]
df4.columns = ['StateName','LanguageName','TotalSpeaker']
df4=df4.iloc[5:]
df4=df4.dropna(axis=0)

df5=pd.read_excel("DDW-C17-1200.XLSX")         #Reading data of Arunachal Pradesh
df5=df5[['Unnamed: 1','Unnamed: 3','Unnamed: 4']]
df5.columns = ['StateName','LanguageName','TotalSpeaker']
df5=df5.iloc[5:]
df5=df5.dropna(axis=0)

df6=pd.read_excel("DDW-C17-1400.XLSX")         #Reading data of Manipur
df6=df6[['Unnamed: 1','Unnamed: 3','Unnamed: 4']]
df6.columns = ['StateName','LanguageName','TotalSpeaker']
df6=df6.iloc[5:]
df6=df6.dropna(axis=0)

df7=pd.read_excel("DDW-C17-1300.XLSX")        #Reading data of Nagaland
df7=df7[['Unnamed: 1','Unnamed: 3','Unnamed: 4']]
df7.columns = ['StateName','LanguageName','TotalSpeaker']
df7=df7.iloc[5:]
df7=df7.dropna(axis=0)

df8=pd.read_excel("DDW-C17-1500.XLSX")        #Reading data of Mizoram
df8=df8[['Unnamed: 1','Unnamed: 3','Unnamed: 4']]
df8.columns = ['StateName','LanguageName','TotalSpeaker']
df8=df8.iloc[5:]

df8=df8.dropna(axis=0)                      #Reading data of Andaman and Nicobar Island
df9=pd.read_excel("DDW-C17-3500.XLSX")
df9=df9[['Unnamed: 1','Unnamed: 3','Unnamed: 4']]
df9.columns = ['StateName','LanguageName','TotalSpeaker']
df9=df9.iloc[5:]
df9=df9.dropna(axis=0)


# In[28]:


dfneast= pd.concat([df1,df2,df3,df4,df5,df6,df7,df8,df9], axis=0)
dfneast=dfneast[['LanguageName','TotalSpeaker']]
dfneast=dfneast[dfneast['LanguageName']!='OTHERS']
dfneast=(dfneast.groupby(dfneast['LanguageName'],as_index=False).aggregate(np.sum).reindex(columns=dfneast.columns))
dfneast=dfneast.sort_values(by=['TotalSpeaker'], ascending=False)
dfneast=dfneast[0:3]
northeast=dfneast['LanguageName'].tolist()
northeast.insert(0,'North-East')
print(northeast)


# In[29]:


colname=['region','language-1','language-2','language-3']
import csv 
with open('region-india-a.csv', 'w') as csvfile: 
      csvwriter = csv.writer(csvfile) 
      csvwriter.writerow(colname)
      csvwriter.writerow(central)
      csvwriter.writerow(east)
      csvwriter.writerow(north)
      csvwriter.writerow(northeast)
      csvwriter.writerow(south)
      csvwriter.writerow(west)


# Part b

# North Region

# In[30]:


dft=pd.read_excel("DDW-C17-0100.XLSX")            #JK
dft1=dft[['Unnamed: 1','Unnamed: 3','Unnamed: 4']]
dft1.columns = ['StateName','LanguageName','Totalspeaker']
dft1=dft1.iloc[5:]
dft1=dft1.dropna(axis=0)
dft2=dft[['Unnamed: 1','Unnamed: 8','Unnamed: 9']]
dft2.columns = ['StateName','LanguageName','Totalspeaker']
dft2=dft2.iloc[5:]
dft2=dft2.dropna(axis=0)
dft3=dft[['Unnamed: 1','Unnamed: 13','Unnamed: 14']]
dft3.columns = ['StateName','LanguageName','Totalspeaker']
dft3=dft3.iloc[5:]
dft3=dft3.dropna(axis=0)
df= pd.concat([dft1,dft2,dft3], axis=0)
df=df.drop('StateName',axis=1)
df=df.groupby(df['LanguageName'],as_index=False).aggregate(np.sum).reindex(columns=df.columns)
df.head()


# In[31]:


dft=pd.read_excel("DDW-C17-0200.XLSX")             #HP
dft1=dft[['Unnamed: 1','Unnamed: 3','Unnamed: 4']]
dft1.columns = ['StateName','LanguageName','Totalspeaker']
dft1=dft1.iloc[5:]
dft1=dft1.dropna(axis=0)
dft2=dft[['Unnamed: 1','Unnamed: 8','Unnamed: 9']]
dft2.columns = ['StateName','LanguageName','Totalspeaker']
dft2=dft2.iloc[5:]
dft2=dft2.dropna(axis=0)
dft3=dft[['Unnamed: 1','Unnamed: 13','Unnamed: 14']]
dft3.columns = ['StateName','LanguageName','Totalspeaker']
dft3=dft3.iloc[5:]
dft3=dft3.dropna(axis=0)
df1= pd.concat([dft1,dft2,dft3], axis=0)
df1=df1.drop('StateName',axis=1)
df1=df1.groupby(df1['LanguageName'],as_index=False).aggregate(np.sum).reindex(columns=df1.columns)
df1.head()


# In[32]:


dft=pd.read_excel("DDW-C17-0300.XLSX")            #PN
dft1=dft[['Unnamed: 1','Unnamed: 3','Unnamed: 4']]
dft1.columns = ['StateName','LanguageName','Totalspeaker']
dft1=dft1.iloc[5:]
dft1=dft1.dropna(axis=0)
dft2=dft[['Unnamed: 1','Unnamed: 8','Unnamed: 9']]
dft2.columns = ['StateName','LanguageName','Totalspeaker']
dft2=dft2.iloc[5:]
dft2=dft2.dropna(axis=0)
dft3=dft[['Unnamed: 1','Unnamed: 13','Unnamed: 14']]
dft3.columns = ['StateName','LanguageName','Totalspeaker']
dft3=dft3.iloc[5:]
dft3=dft3.dropna(axis=0)
df2= pd.concat([dft1,dft2,dft3], axis=0)
df2=df2.drop('StateName',axis=1)
df2=df2.groupby(df2['LanguageName'],as_index=False).aggregate(np.sum).reindex(columns=df2.columns)
df2.head()


# In[33]:


dft=pd.read_excel("DDW-C17-0400.XLSX")          #CH
dft1=dft[['Unnamed: 1','Unnamed: 3','Unnamed: 4']]
dft1.columns = ['StateName','LanguageName','Totalspeaker']
dft1=dft1.iloc[5:]
dft1=dft1.dropna(axis=0)
dft2=dft[['Unnamed: 1','Unnamed: 8','Unnamed: 9']]
dft2.columns = ['StateName','LanguageName','Totalspeaker']
dft2=dft2.iloc[5:]
dft2=dft2.dropna(axis=0)
dft3=dft[['Unnamed: 1','Unnamed: 13','Unnamed: 14']]
dft3.columns = ['StateName','LanguageName','Totalspeaker']
dft3=dft3.iloc[5:]
dft3=dft3.dropna(axis=0)
df3= pd.concat([dft1,dft2,dft3], axis=0)
df3=df3.drop('StateName',axis=1)
df3=df3.groupby(df3['LanguageName'],as_index=False).aggregate(np.sum).reindex(columns=df3.columns)
df3.head()


# In[34]:


dft=pd.read_excel("DDW-C17-0500.XLSX")      #UK
dft1=dft[['Unnamed: 1','Unnamed: 3','Unnamed: 4']]
dft1.columns = ['StateName','LanguageName','Totalspeaker']
dft1=dft1.iloc[5:]
dft1=dft1.dropna(axis=0)
dft2=dft[['Unnamed: 1','Unnamed: 8','Unnamed: 9']]
dft2.columns = ['StateName','LanguageName','Totalspeaker']
dft2=dft2.iloc[5:]
dft2=dft2.dropna(axis=0)
dft3=dft[['Unnamed: 1','Unnamed: 13','Unnamed: 14']]
dft3.columns = ['StateName','LanguageName','Totalspeaker']
dft3=dft3.iloc[5:]
dft3=dft3.dropna(axis=0)
df4= pd.concat([dft1,dft2,dft3], axis=0)
df4=df4.drop('StateName',axis=1)
df4=df4.groupby(df4['LanguageName'],as_index=False).aggregate(np.sum).reindex(columns=df4.columns)
df4.head()


# In[35]:


dft=pd.read_excel("DDW-C17-0600.XLSX")            #HR
dft1=dft[['Unnamed: 1','Unnamed: 3','Unnamed: 4']]
dft1.columns = ['StateName','LanguageName','Totalspeaker']
dft1=dft1.iloc[5:]
dft1=dft1.dropna(axis=0)
dft2=dft[['Unnamed: 1','Unnamed: 8','Unnamed: 9']]
dft2.columns = ['StateName','LanguageName','Totalspeaker']
dft2=dft2.iloc[5:]
dft2=dft2.dropna(axis=0)
dft3=dft[['Unnamed: 1','Unnamed: 13','Unnamed: 14']]
dft3.columns = ['StateName','LanguageName','Totalspeaker']
dft3=dft3.iloc[5:]
dft3=dft3.dropna(axis=0)
df5= pd.concat([dft1,dft2,dft3], axis=0)
df5=df5.drop('StateName',axis=1)
df5=df5.groupby(df5['LanguageName'],as_index=False).aggregate(np.sum).reindex(columns=df5.columns)
df5.head()


# In[36]:


dft=pd.read_excel("DDW-C17-0700.XLSX")           #DL
dft1=dft[['Unnamed: 1','Unnamed: 3','Unnamed: 4']]
dft1.columns = ['StateName','LanguageName','Totalspeaker']
dft1=dft1.iloc[5:]
dft1=dft1.dropna(axis=0)
dft2=dft[['Unnamed: 1','Unnamed: 8','Unnamed: 9']]
dft2.columns = ['StateName','LanguageName','Totalspeaker']
dft2=dft2.iloc[5:]
dft2=dft2.dropna(axis=0)
dft3=dft[['Unnamed: 1','Unnamed: 13','Unnamed: 14']]
dft3.columns = ['StateName','LanguageName','Totalspeaker']
dft3=dft3.iloc[5:]
dft3=dft3.dropna(axis=0)
df6= pd.concat([dft1,dft2,dft3], axis=0)
df6=df6.drop('StateName',axis=1)
df6=df6.groupby(df6['LanguageName'],as_index=False).aggregate(np.sum).reindex(columns=df6.columns)
df6.head()


# In[37]:


dfnorth= pd.concat([df,df1,df2,df3,df4,df5,df6], axis=0)
dfnorth=dfnorth[dfnorth['LanguageName']!='OTHERS']
dfnorth=(dfnorth.groupby(dfnorth['LanguageName'],as_index=False).aggregate(np.sum).reindex(columns=dfnorth.columns))
dfnorth=dfnorth.sort_values(by=['Totalspeaker'], ascending=False)
dfnorth.head(3)
dfnorth=dfnorth[0:3]
dfnorth=dfnorth[['LanguageName']]
north=dfnorth['LanguageName'].tolist()
north.insert(0,'North')
print(north)


# West Region

# In[38]:


dft=pd.read_excel("DDW-C17-0800.XLSX")                #RJ
dft1=dft[['Unnamed: 1','Unnamed: 3','Unnamed: 4']]
dft1.columns = ['StateName','LanguageName','Totalspeaker']
dft1=dft1.iloc[5:]
dft1=dft1.dropna(axis=0)
dft2=dft[['Unnamed: 1','Unnamed: 8','Unnamed: 9']]
dft2.columns = ['StateName','LanguageName','Totalspeaker']
dft2=dft2.iloc[5:]
dft2=dft2.dropna(axis=0)
dft3=dft[['Unnamed: 1','Unnamed: 13','Unnamed: 14']]
dft3.columns = ['StateName','LanguageName','Totalspeaker']
dft3=dft3.iloc[5:]
dft3=dft3.dropna(axis=0)
df= pd.concat([dft1,dft2,dft3], axis=0)
df=df.drop('StateName',axis=1)
df=df.groupby(df['LanguageName'],as_index=False).aggregate(np.sum).reindex(columns=df.columns)
df.head()

dft=pd.read_excel("DDW-C17-2400.XLSX")            #GJ
dft1=dft[['Unnamed: 1','Unnamed: 3','Unnamed: 4']]
dft1.columns = ['StateName','LanguageName','Totalspeaker']
dft1=dft1.iloc[5:]
dft1=dft1.dropna(axis=0)
dft2=dft[['Unnamed: 1','Unnamed: 8','Unnamed: 9']]
dft2.columns = ['StateName','LanguageName','Totalspeaker']
dft2=dft2.iloc[5:]
dft2=dft2.dropna(axis=0)
dft3=dft[['Unnamed: 1','Unnamed: 13','Unnamed: 14']]
dft3.columns = ['StateName','LanguageName','Totalspeaker']
dft3=dft3.iloc[5:]
dft3=dft3.dropna(axis=0)
df1= pd.concat([dft1,dft2,dft3], axis=0)
df1=df1.drop('StateName',axis=1)
df1=df1.groupby(df1['LanguageName'],as_index=False).aggregate(np.sum).reindex(columns=df1.columns)
df1.head()

dft=pd.read_excel("DDW-C17-2700.XLSX")             #MH
dft1=dft[['Unnamed: 1','Unnamed: 3','Unnamed: 4']]
dft1.columns = ['StateName','LanguageName','Totalspeaker']
dft1=dft1.iloc[5:]
dft1=dft1.dropna(axis=0)
dft2=dft[['Unnamed: 1','Unnamed: 8','Unnamed: 9']]
dft2.columns = ['StateName','LanguageName','Totalspeaker']
dft2=dft2.iloc[5:]
dft2=dft2.dropna(axis=0)
dft3=dft[['Unnamed: 1','Unnamed: 13','Unnamed: 14']]
dft3.columns = ['StateName','LanguageName','Totalspeaker']
dft3=dft3.iloc[5:]
dft3=dft3.dropna(axis=0)
df2= pd.concat([dft1,dft2,dft3], axis=0)
df2=df2.drop('StateName',axis=1)
df2=df2.groupby(df2['LanguageName'],as_index=False).aggregate(np.sum).reindex(columns=df2.columns)
df2.head()

dft=pd.read_excel("DDW-C17-3000.XLSX")             #GA
dft1=dft[['Unnamed: 1','Unnamed: 3','Unnamed: 4']]
dft1.columns = ['StateName','LanguageName','Totalspeaker']
dft1=dft1.iloc[5:]
dft1=dft1.dropna(axis=0)
dft2=dft[['Unnamed: 1','Unnamed: 8','Unnamed: 9']]
dft2.columns = ['StateName','LanguageName','Totalspeaker']
dft2=dft2.iloc[5:]
dft2=dft2.dropna(axis=0)
dft3=dft[['Unnamed: 1','Unnamed: 13','Unnamed: 14']]
dft3.columns = ['StateName','LanguageName','Totalspeaker']
dft3=dft3.iloc[5:]
dft3=dft3.dropna(axis=0)
df3= pd.concat([dft1,dft2,dft3], axis=0)
df3=df3.drop('StateName',axis=1)
df3=df3.groupby(df3['LanguageName'],as_index=False).aggregate(np.sum).reindex(columns=df3.columns)
df3.head()

dft=pd.read_excel("DDW-C17-2500.XLSX")            #DD
dft1=dft[['Unnamed: 1','Unnamed: 3','Unnamed: 4']]
dft1.columns = ['StateName','LanguageName','Totalspeaker']
dft1=dft1.iloc[5:]
dft1=dft1.dropna(axis=0)
dft2=dft[['Unnamed: 1','Unnamed: 8','Unnamed: 9']]
dft2.columns = ['StateName','LanguageName','Totalspeaker']
dft2=dft2.iloc[5:]
dft2=dft2.dropna(axis=0)
dft3=dft[['Unnamed: 1','Unnamed: 13','Unnamed: 14']]
dft3.columns = ['StateName','LanguageName','Totalspeaker']
dft3=dft3.iloc[5:]
dft3=dft3.dropna(axis=0)
df4= pd.concat([dft1,dft2,dft3], axis=0)
df4=df4.drop('StateName',axis=1)
df4=df4.groupby(df4['LanguageName'],as_index=False).aggregate(np.sum).reindex(columns=df4.columns)
df4.head()

dft=pd.read_excel("DDW-C17-2600.XLSX")           #DN
dft1=dft[['Unnamed: 1','Unnamed: 3','Unnamed: 4']]
dft1.columns = ['StateName','LanguageName','Totalspeaker']
dft1=dft1.iloc[5:]
dft1=dft1.dropna(axis=0)
dft2=dft[['Unnamed: 1','Unnamed: 8','Unnamed: 9']]
dft2.columns = ['StateName','LanguageName','Totalspeaker']
dft2=dft2.iloc[5:]
dft2=dft2.dropna(axis=0)
dft3=dft[['Unnamed: 1','Unnamed: 13','Unnamed: 14']]
dft3.columns = ['StateName','LanguageName','Totalspeaker']
dft3=dft3.iloc[5:]
dft3=dft3.dropna(axis=0)
df5= pd.concat([dft1,dft2,dft3], axis=0)
df5=df5.drop('StateName',axis=1)
df5=df5.groupby(df5['LanguageName'],as_index=False).aggregate(np.sum).reindex(columns=df5.columns)
df5.head()


# In[39]:


dfwest= pd.concat([df,df1,df2,df3,df4,df5], axis=0)
dfwest=dfwest[dfwest['LanguageName']!='OTHERS']
dfwest=(dfwest.groupby(dfwest['LanguageName'],as_index=False).aggregate(np.sum).reindex(columns=dfwest.columns))
dfwest=dfwest.sort_values(by=['Totalspeaker'], ascending=False)
dfwest=dfwest[0:3]
dfwest=dfwest[['LanguageName']]
west=dfwest['LanguageName'].tolist()
west.insert(0,'West')
print(west)


# Central

# In[40]:


dft=pd.read_excel("DDW-C17-2300.XLSX")             #MP
dft1=dft[['Unnamed: 1','Unnamed: 3','Unnamed: 4']]
dft1.columns = ['StateName','LanguageName','Totalspeaker']
dft1=dft1.iloc[5:]
dft1=dft1.dropna(axis=0)
dft2=dft[['Unnamed: 1','Unnamed: 8','Unnamed: 9']]
dft2.columns = ['StateName','LanguageName','Totalspeaker']
dft2=dft2.iloc[5:]
dft2=dft2.dropna(axis=0)
dft3=dft[['Unnamed: 1','Unnamed: 13','Unnamed: 14']]
dft3.columns = ['StateName','LanguageName','Totalspeaker']
dft3=dft3.iloc[5:]
dft3=dft3.dropna(axis=0)
df= pd.concat([dft1,dft2,dft3], axis=0)
df=df.drop('StateName',axis=1)
df=df.groupby(df['LanguageName'],as_index=False).aggregate(np.sum).reindex(columns=df.columns)
df.head()

dft=pd.read_excel("DDW-C17-0900.XLSX")            #UP
dft1=dft[['Unnamed: 1','Unnamed: 3','Unnamed: 4']]
dft1.columns = ['StateName','LanguageName','Totalspeaker']
dft1=dft1.iloc[5:]
dft1=dft1.dropna(axis=0)
dft2=dft[['Unnamed: 1','Unnamed: 8','Unnamed: 9']]
dft2.columns = ['StateName','LanguageName','Totalspeaker']
dft2=dft2.iloc[5:]
dft2=dft2.dropna(axis=0)
dft3=dft[['Unnamed: 1','Unnamed: 13','Unnamed: 14']]
dft3.columns = ['StateName','LanguageName','Totalspeaker']
dft3=dft3.iloc[5:]
dft3=dft3.dropna(axis=0)
df1= pd.concat([dft1,dft2,dft3], axis=0)
df1=df1.drop('StateName',axis=1)
df1=df1.groupby(df1['LanguageName'],as_index=False).aggregate(np.sum).reindex(columns=df1.columns)
df1.head()

dft=pd.read_excel("DDW-C17-2200.XLSX")           #CG
dft1=dft[['Unnamed: 1','Unnamed: 3','Unnamed: 4']]
dft1.columns = ['StateName','LanguageName','Totalspeaker']
dft1=dft1.iloc[5:]
dft1=dft1.dropna(axis=0)
dft2=dft[['Unnamed: 1','Unnamed: 8','Unnamed: 9']]
dft2.columns = ['StateName','LanguageName','Totalspeaker']
dft2=dft2.iloc[5:]
dft2=dft2.dropna(axis=0)
dft3=dft[['Unnamed: 1','Unnamed: 13','Unnamed: 14']]
dft3.columns = ['StateName','LanguageName','Totalspeaker']
dft3=dft3.iloc[5:]
dft3=dft3.dropna(axis=0)
df2= pd.concat([dft1,dft2,dft3], axis=0)
df2=df2.drop('StateName',axis=1)
df2=df2.groupby(df2['LanguageName'],as_index=False).aggregate(np.sum).reindex(columns=df2.columns)
df2.head()                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                 


# In[41]:


dfcentral= pd.concat([df,df2,df1], axis=0)
dfcentral=dfcentral[dfcentral['LanguageName']!='OTHERS']
dfcentral=(dfcentral.groupby(dfcentral['LanguageName'],as_index=False).aggregate(np.sum).reindex(columns=dfcentral.columns))
dfcentral=dfcentral.sort_values(by=['Totalspeaker'], ascending=False)
dfcentral=dfcentral[0:3]
central=dfcentral['LanguageName'].tolist()
central.insert(0,'Central')
print(central)


# East Region

# In[42]:


dft=pd.read_excel("DDW-C17-1000.XLSX")           #BH
dft1=dft[['Unnamed: 1','Unnamed: 3','Unnamed: 4']]
dft1.columns = ['StateName','LanguageName','Totalspeaker']
dft1=dft1.iloc[5:]
dft1=dft1.dropna(axis=0)
dft2=dft[['Unnamed: 1','Unnamed: 8','Unnamed: 9']]
dft2.columns = ['StateName','LanguageName','Totalspeaker']
dft2=dft2.iloc[5:]
dft2=dft2.dropna(axis=0)
dft3=dft[['Unnamed: 1','Unnamed: 13','Unnamed: 14']]
dft3.columns = ['StateName','LanguageName','Totalspeaker']
dft3=dft3.iloc[5:]
dft3=dft3.dropna(axis=0)
df= pd.concat([dft1,dft2,dft3], axis=0)
df=df.drop('StateName',axis=1)
df=df.groupby(df['LanguageName'],as_index=False).aggregate(np.sum).reindex(columns=df.columns)
df.head()

dft=pd.read_excel("DDW-C17-1900.XLSX")            #WB
dft1=dft[['Unnamed: 1','Unnamed: 3','Unnamed: 4']]
dft1.columns = ['StateName','LanguageName','Totalspeaker']
dft1=dft1.iloc[5:]
dft1=dft1.dropna(axis=0)
dft2=dft[['Unnamed: 1','Unnamed: 8','Unnamed: 9']]
dft2.columns = ['StateName','LanguageName','Totalspeaker']
dft2=dft2.iloc[5:]
dft2=dft2.dropna(axis=0)
dft3=dft[['Unnamed: 1','Unnamed: 13','Unnamed: 14']]
dft3.columns = ['StateName','LanguageName','Totalspeaker']
dft3=dft3.iloc[5:]
dft3=dft3.dropna(axis=0)
df1= pd.concat([dft1,dft2,dft3], axis=0)
df1=df1.drop('StateName',axis=1)
df1=df1.groupby(df1['LanguageName'],as_index=False).aggregate(np.sum).reindex(columns=df1.columns)
df1.head()

dft=pd.read_excel("DDW-C17-2100.XLSX")             #OR
dft1=dft[['Unnamed: 1','Unnamed: 3','Unnamed: 4']]
dft1.columns = ['StateName','LanguageName','Totalspeaker']
dft1=dft1.iloc[5:]
dft1=dft1.dropna(axis=0)
dft2=dft[['Unnamed: 1','Unnamed: 8','Unnamed: 9']]
dft2.columns = ['StateName','LanguageName','Totalspeaker']
dft2=dft2.iloc[5:]
dft2=dft2.dropna(axis=0)
dft3=dft[['Unnamed: 1','Unnamed: 13','Unnamed: 14']]
dft3.columns = ['StateName','LanguageName','Totalspeaker']
dft3=dft3.iloc[5:]
dft3=dft3.dropna(axis=0)
df2= pd.concat([dft1,dft2,dft3], axis=0)
df2=df2.drop('StateName',axis=1)
df2=df2.groupby(df2['LanguageName'],as_index=False).aggregate(np.sum).reindex(columns=df2.columns)
df2.head()

dft=pd.read_excel("DDW-C17-2000.XLSX")             #JH
dft1=dft[['Unnamed: 1','Unnamed: 3','Unnamed: 4']]
dft1.columns = ['StateName','LanguageName','Totalspeaker']
dft1=dft1.iloc[5:]
dft1=dft1.dropna(axis=0)
dft2=dft[['Unnamed: 1','Unnamed: 8','Unnamed: 9']]
dft2.columns = ['StateName','LanguageName','Totalspeaker']
dft2=dft2.iloc[5:]
dft2=dft2.dropna(axis=0)
dft3=dft[['Unnamed: 1','Unnamed: 13','Unnamed: 14']]
dft3.columns = ['StateName','LanguageName','Totalspeaker']
dft3=dft3.iloc[5:]
dft3=dft3.dropna(axis=0)
df3= pd.concat([dft1,dft2,dft3], axis=0)
df3=df3.drop('StateName',axis=1)
df3=df3.groupby(df3['LanguageName'],as_index=False).aggregate(np.sum).reindex(columns=df3.columns)
df3.head()


# In[43]:


dfeast= pd.concat([df,df1,df2,df3], axis=0)
dfeast=dfeast[dfeast['LanguageName']!='OTHERS']
dfeast=(dfeast.groupby(dfeast['LanguageName'],as_index=False).aggregate(np.sum).reindex(columns=dfeast.columns))
dfeast=dfeast.sort_values(by=['Totalspeaker'], ascending=False)
dfeast=dfeast[0:3]
east=dfeast['LanguageName'].tolist()
east.insert(0,'East')
print(east)


# South

# In[44]:


dft=pd.read_excel("DDW-C17-2900.XLSX")                 #KA
dft1=dft[['Unnamed: 1','Unnamed: 3','Unnamed: 4']]
dft1.columns = ['StateName','LanguageName','Totalspeaker']
dft1=dft1.iloc[5:]
dft1=dft1.dropna(axis=0)
dft2=dft[['Unnamed: 1','Unnamed: 8','Unnamed: 9']]
dft2.columns = ['StateName','LanguageName','Totalspeaker']
dft2=dft2.iloc[5:]
dft2=dft2.dropna(axis=0)
dft3=dft[['Unnamed: 1','Unnamed: 13','Unnamed: 14']]
dft3.columns = ['StateName','LanguageName','Totalspeaker']
dft3=dft3.iloc[5:]
dft3=dft3.dropna(axis=0)
df= pd.concat([dft1,dft2,dft3], axis=0)
df=df.drop('StateName',axis=1)
df=df.groupby(df['LanguageName'],as_index=False).aggregate(np.sum).reindex(columns=df.columns)
df.head()

dft=pd.read_excel("DDW-C17-2800.XLSX")             #AP
dft1=dft[['Unnamed: 1','Unnamed: 3','Unnamed: 4']]
dft1.columns = ['StateName','LanguageName','Totalspeaker']
dft1=dft1.iloc[5:]
dft1=dft1.dropna(axis=0)
dft2=dft[['Unnamed: 1','Unnamed: 8','Unnamed: 9']]
dft2.columns = ['StateName','LanguageName','Totalspeaker']
dft2=dft2.iloc[5:]
dft2=dft2.dropna(axis=0)
dft3=dft[['Unnamed: 1','Unnamed: 13','Unnamed: 14']]
dft3.columns = ['StateName','LanguageName','Totalspeaker']
dft3=dft3.iloc[5:]
dft3=dft3.dropna(axis=0)
df1= pd.concat([dft1,dft2,dft3], axis=0)
df1=df1.drop('StateName',axis=1)
df1=df1.groupby(df1['LanguageName'],as_index=False).aggregate(np.sum).reindex(columns=df1.columns)
df1.head()

dft=pd.read_excel("DDW-C17-3300.XLSX")            #TN
dft1=dft[['Unnamed: 1','Unnamed: 3','Unnamed: 4']]
dft1.columns = ['StateName','LanguageName','Totalspeaker']
dft1=dft1.iloc[5:]
dft1=dft1.dropna(axis=0)
dft2=dft[['Unnamed: 1','Unnamed: 8','Unnamed: 9']]
dft2.columns = ['StateName','LanguageName','Totalspeaker']
dft2=dft2.iloc[5:]
dft2=dft2.dropna(axis=0)
dft3=dft[['Unnamed: 1','Unnamed: 13','Unnamed: 14']]
dft3.columns = ['StateName','LanguageName','Totalspeaker']
dft3=dft3.iloc[5:]
dft3=dft3.dropna(axis=0)
df2= pd.concat([dft1,dft2,dft3], axis=0)
df2=df2.drop('StateName',axis=1)
df2=df2.groupby(df2['LanguageName'],as_index=False).aggregate(np.sum).reindex(columns=df2.columns)
df2.head()

dft=pd.read_excel("DDW-C17-3200.XLSX")           #KL
dft1=dft[['Unnamed: 1','Unnamed: 3','Unnamed: 4']]
dft1.columns = ['StateName','LanguageName','Totalspeaker']
dft1=dft1.iloc[5:]
dft1=dft1.dropna(axis=0)
dft2=dft[['Unnamed: 1','Unnamed: 8','Unnamed: 9']]
dft2.columns = ['StateName','LanguageName','Totalspeaker']
dft2=dft2.iloc[5:]
dft2=dft2.dropna(axis=0)
dft3=dft[['Unnamed: 1','Unnamed: 13','Unnamed: 14']]
dft3.columns = ['StateName','LanguageName','Totalspeaker']
dft3=dft3.iloc[5:]
dft3=dft3.dropna(axis=0)
df3= pd.concat([dft1,dft2,dft3], axis=0)
df3=df3.drop('StateName',axis=1)
df3=df3.groupby(df3['LanguageName'],as_index=False).aggregate(np.sum).reindex(columns=df3.columns)
df3.head()

dft=pd.read_excel("DDW-C17-3100.XLSX")            #LD
dft1=dft[['Unnamed: 1','Unnamed: 3','Unnamed: 4']]
dft1.columns = ['StateName','LanguageName','Totalspeaker']
dft1=dft1.iloc[5:]
dft1=dft1.dropna(axis=0)
dft2=dft[['Unnamed: 1','Unnamed: 8','Unnamed: 9']]
dft2.columns = ['StateName','LanguageName','Totalspeaker']
dft2=dft2.iloc[5:]
dft2=dft2.dropna(axis=0)
dft3=dft[['Unnamed: 1','Unnamed: 13','Unnamed: 14']]
dft3.columns = ['StateName','LanguageName','Totalspeaker']
dft3=dft3.iloc[5:]
dft3=dft3.dropna(axis=0)
df4= pd.concat([dft1,dft2,dft3], axis=0)
df4=df4.drop('StateName',axis=1)
df4=df4.groupby(df4['LanguageName'],as_index=False).aggregate(np.sum).reindex(columns=df4.columns)
df4.head()

dft=pd.read_excel("DDW-C17-3400.XLSX")             #PY
dft1=dft[['Unnamed: 1','Unnamed: 3','Unnamed: 4']]
dft1.columns = ['StateName','LanguageName','Totalspeaker']
dft1=dft1.iloc[5:]
dft1=dft1.dropna(axis=0)
dft2=dft[['Unnamed: 1','Unnamed: 8','Unnamed: 9']]
dft2.columns = ['StateName','LanguageName','Totalspeaker']
dft2=dft2.iloc[5:]
dft2=dft2.dropna(axis=0)
dft3=dft[['Unnamed: 1','Unnamed: 13','Unnamed: 14']]
dft3.columns = ['StateName','LanguageName','Totalspeaker']
dft3=dft3.iloc[5:]
dft3=dft3.dropna(axis=0)
df5= pd.concat([dft1,dft2,dft3], axis=0)
df5=df5.drop('StateName',axis=1)
df5=df5.groupby(df5['LanguageName'],as_index=False).aggregate(np.sum).reindex(columns=df5.columns)
df5.head()


# In[45]:


dfsouth= pd.concat([df,df1,df2,df3,df4,df5], axis=0)
dfsouth=dfsouth[dfsouth['LanguageName']!='OTHERS']
dfsouth=(dfsouth.groupby(dfsouth['LanguageName'],as_index=False).aggregate(np.sum).reindex(columns=dfsouth.columns))
dfsouth=dfsouth.sort_values(by=['Totalspeaker'], ascending=False)
dfsouth=dfsouth[0:3]
south=dfsouth['LanguageName'].tolist()
south.insert(0,'South')
print(south)


# North-East

# In[46]:


dft=pd.read_excel("DDW-C17-1800.XLSX")            #AS
dft1=dft[['Unnamed: 1','Unnamed: 3','Unnamed: 4']]
dft1.columns = ['StateName','LanguageName','Totalspeaker']
dft1=dft1.iloc[5:]
dft1=dft1.dropna(axis=0)
dft2=dft[['Unnamed: 1','Unnamed: 8','Unnamed: 9']]
dft2.columns = ['StateName','LanguageName','Totalspeaker']
dft2=dft2.iloc[5:]
dft2=dft2.dropna(axis=0)
dft3=dft[['Unnamed: 1','Unnamed: 13','Unnamed: 14']]
dft3.columns = ['StateName','LanguageName','Totalspeaker']
dft3=dft3.iloc[5:]
dft3=dft3.dropna(axis=0)
df= pd.concat([dft1,dft2,dft3], axis=0)
df=df.drop('StateName',axis=1)
df=df.groupby(df['LanguageName'],as_index=False).aggregate(np.sum).reindex(columns=df.columns)
df.head()

dft=pd.read_excel("DDW-C17-1100.XLSX")           #SK
dft1=dft[['Unnamed: 1','Unnamed: 3','Unnamed: 4']]
dft1.columns = ['StateName','LanguageName','Totalspeaker']
dft1=dft1.iloc[5:]
dft1=dft1.dropna(axis=0)
dft2=dft[['Unnamed: 1','Unnamed: 8','Unnamed: 9']]
dft2.columns = ['StateName','LanguageName','Totalspeaker']
dft2=dft2.iloc[5:]
dft2=dft2.dropna(axis=0)
dft3=dft[['Unnamed: 1','Unnamed: 13','Unnamed: 14']]
dft3.columns = ['StateName','LanguageName','Totalspeaker']
dft3=dft3.iloc[5:]
dft3=dft3.dropna(axis=0)
df1= pd.concat([dft1,dft2,dft3], axis=0)
df1=df1.drop('StateName',axis=1)
df1=df1.groupby(df1['LanguageName'],as_index=False).aggregate(np.sum).reindex(columns=df1.columns)
df1.head()

dft=pd.read_excel("DDW-C17-1700.XLSX")         #MG
dft1=dft[['Unnamed: 1','Unnamed: 3','Unnamed: 4']]
dft1.columns = ['StateName','LanguageName','Totalspeaker']
dft1=dft1.iloc[5:]
dft1=dft1.dropna(axis=0)
dft2=dft[['Unnamed: 1','Unnamed: 8','Unnamed: 9']]
dft2.columns = ['StateName','LanguageName','Totalspeaker']
dft2=dft2.iloc[5:]
dft2=dft2.dropna(axis=0)
dft3=dft[['Unnamed: 1','Unnamed: 13','Unnamed: 14']]
dft3.columns = ['StateName','LanguageName','Totalspeaker']
dft3=dft3.iloc[5:]
dft3=dft3.dropna(axis=0)
df2= pd.concat([dft1,dft2,dft3], axis=0)
df2=df2.drop('StateName',axis=1)
df2=df2.groupby(df2['LanguageName'],as_index=False).aggregate(np.sum).reindex(columns=df2.columns)
df2.head()

dft=pd.read_excel("DDW-C17-1600.XLSX")            #TR
dft1=dft[['Unnamed: 1','Unnamed: 3','Unnamed: 4']]
dft1.columns = ['StateName','LanguageName','Totalspeaker']
dft1=dft1.iloc[5:]
dft1=dft1.dropna(axis=0)
dft2=dft[['Unnamed: 1','Unnamed: 8','Unnamed: 9']]
dft2.columns = ['StateName','LanguageName','Totalspeaker']
dft2=dft2.iloc[5:]
dft2=dft2.dropna(axis=0)
dft3=dft[['Unnamed: 1','Unnamed: 13','Unnamed: 14']]
dft3.columns = ['StateName','LanguageName','Totalspeaker']
dft3=dft3.iloc[5:]
dft3=dft3.dropna(axis=0)
df3= pd.concat([dft1,dft2,dft3], axis=0)
df3=df3.drop('StateName',axis=1)
df3=df3.groupby(df3['LanguageName'],as_index=False).aggregate(np.sum).reindex(columns=df3.columns)
df3.head()

dft=pd.read_excel("DDW-C17-1200.XLSX")            #AR
dft1=dft[['Unnamed: 1','Unnamed: 3','Unnamed: 4']]
dft1.columns = ['StateName','LanguageName','Totalspeaker']
dft1=dft1.iloc[5:]
dft1=dft1.dropna(axis=0)
dft2=dft[['Unnamed: 1','Unnamed: 8','Unnamed: 9']]
dft2.columns = ['StateName','LanguageName','Totalspeaker']
dft2=dft2.iloc[5:]
dft2=dft2.dropna(axis=0)
dft3=dft[['Unnamed: 1','Unnamed: 13','Unnamed: 14']]
dft3.columns = ['StateName','LanguageName','Totalspeaker']
dft3=dft3.iloc[5:]
dft3=dft3.dropna(axis=0)
df4= pd.concat([dft1,dft2,dft3], axis=0)
df4=df4.drop('StateName',axis=1)
df4=df4.groupby(df4['LanguageName'],as_index=False).aggregate(np.sum).reindex(columns=df4.columns)
df4.head()

dft=pd.read_excel("DDW-C17-1400.XLSX")             #MN
dft1=dft[['Unnamed: 1','Unnamed: 3','Unnamed: 4']]
dft1.columns = ['StateName','LanguageName','Totalspeaker']
dft1=dft1.iloc[5:]
dft1=dft1.dropna(axis=0) 
dft2=dft[['Unnamed: 1','Unnamed: 8','Unnamed: 9']]
dft2.columns = ['StateName','LanguageName','Totalspeaker']
dft2=dft2.iloc[5:]
dft2=dft2.dropna(axis=0)
dft3=dft[['Unnamed: 1','Unnamed: 13','Unnamed: 14']]
dft3.columns = ['StateName','LanguageName','Totalspeaker']
dft3=dft3.iloc[5:]
dft3=dft3.dropna(axis=0)
df5= pd.concat([dft1,dft2,dft3], axis=0)
df5=df5.drop('StateName',axis=1)
df5=df5.groupby(df5['LanguageName'],as_index=False).aggregate(np.sum).reindex(columns=df5.columns)
df5.head()

dft=pd.read_excel("DDW-C17-1300.XLSX")               #NG
dft1=dft[['Unnamed: 1','Unnamed: 3','Unnamed: 4']]
dft1.columns = ['StateName','LanguageName','Totalspeaker']
dft1=dft1.iloc[5:]
dft1=dft1.dropna(axis=0)
dft2=dft[['Unnamed: 1','Unnamed: 8','Unnamed: 9']]
dft2.columns = ['StateName','LanguageName','Totalspeaker']
dft2=dft2.iloc[5:]
dft2=dft2.dropna(axis=0)
dft3=dft[['Unnamed: 1','Unnamed: 13','Unnamed: 14']]
dft3.columns = ['StateName','LanguageName','Totalspeaker']
dft3=dft3.iloc[5:]
dft3=dft3.dropna(axis=0)
df6= pd.concat([dft1,dft2,dft3], axis=0)
df6=df6.drop('StateName',axis=1)
df6=df6.groupby(df6['LanguageName'],as_index=False).aggregate(np.sum).reindex(columns=df6.columns)
df6.head()

dft=pd.read_excel("DDW-C17-1500.XLSX")             #MZ
dft1=dft[['Unnamed: 1','Unnamed: 3','Unnamed: 4']]
dft1.columns = ['StateName','LanguageName','Totalspeaker']
dft1=dft1.iloc[5:]
dft1=dft1.dropna(axis=0)
dft2=dft[['Unnamed: 1','Unnamed: 8','Unnamed: 9']]
dft2.columns = ['StateName','LanguageName','Totalspeaker']
dft2=dft2.iloc[5:]
dft2=dft2.dropna(axis=0)
dft3=dft[['Unnamed: 1','Unnamed: 13','Unnamed: 14']]
dft3.columns = ['StateName','LanguageName','Totalspeaker']
dft3=dft3.iloc[5:]
dft3=dft3.dropna(axis=0)
df7= pd.concat([dft1,dft2,dft3], axis=0)
df7=df7.drop('StateName',axis=1)
df7=df7.groupby(df7['LanguageName'],as_index=False).aggregate(np.sum).reindex(columns=df7.columns)
df7.head()

dft=pd.read_excel("DDW-C17-3500.XLSX")             #AN
dft1=dft[['Unnamed: 1','Unnamed: 3','Unnamed: 4']]
dft1.columns = ['StateName','LanguageName','Totalspeaker']
dft1=dft1.iloc[5:]
dft1=dft1.dropna(axis=0)
dft2=dft[['Unnamed: 1','Unnamed: 8','Unnamed: 9']]
dft2.columns = ['StateName','LanguageName','Totalspeaker']
dft2=dft2.iloc[5:]
dft2=dft2.dropna(axis=0)
dft3=dft[['Unnamed: 1','Unnamed: 13','Unnamed: 14']]
dft3.columns = ['StateName','LanguageName','Totalspeaker']
dft3=dft3.iloc[5:]
dft3=dft3.dropna(axis=0)
df8= pd.concat([dft1,dft2,dft3], axis=0)
df8=df8.drop('StateName',axis=1)
df8=df8.groupby(df8['LanguageName'],as_index=False).aggregate(np.sum).reindex(columns=df8.columns)
df8.head()


# In[47]:


dfneast= pd.concat([df,df1,df2,df3,df4,df5,df6,df7,df8], axis=0)
dfneast=dfneast[dfneast['LanguageName']!='OTHERS']
dfneast=(dfneast.groupby(dfneast['LanguageName'],as_index=False).aggregate(np.sum).reindex(columns=dfneast.columns))
dfneast=dfneast.sort_values(by=['Totalspeaker'], ascending=False)
dfneast=dfneast[0:3]
northeast=dfneast['LanguageName'].tolist()
northeast.insert(0,'North-East')
print(northeast)


# In[48]:


colname=['region','language-1','language-2','language-3']
import csv 
with open('region-india-b.csv', 'w') as csvfile: 
      csvwriter = csv.writer(csvfile) 
      csvwriter.writerow(colname)
      csvwriter.writerow(central)
      csvwriter.writerow(east)
      csvwriter.writerow(north)
      csvwriter.writerow(northeast)
      csvwriter.writerow(south)
      csvwriter.writerow(west)

