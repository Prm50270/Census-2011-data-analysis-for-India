#!/bin/bash
python3 dmq9.py
