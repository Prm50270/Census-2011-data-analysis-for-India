#!/bin/bash
python3 dmq6.py
