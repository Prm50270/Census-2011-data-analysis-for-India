#!/bin/bash
python3 dmq7.py
