#!/bin/bash
python3 dmq8.py
