#!/bin/bash
python3 dmq2.py
