#!/bin/bash
python3 dmq5.py
