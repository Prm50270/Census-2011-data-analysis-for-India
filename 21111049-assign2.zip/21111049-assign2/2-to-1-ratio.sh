#!/bin/bash
python3 dmq4b.py
